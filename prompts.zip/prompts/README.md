# Hospitality OS

> Hospitality Operating System for Modern Short-Term Rentals

Version: 1.0 (Draft)

Author: Hospitality OS Team

---

# Vision

Hospitality OS is a modular platform for managing short-term rental properties.

Unlike a traditional PMS or Channel Manager, Hospitality OS focuses on everything that happens **before**, **during** and **after** a guest stay.

The platform connects three groups:

- Property Owners
- Guests
- Local Service Providers

The goal is to provide the best guest experience while reducing manual work for property owners and creating a marketplace for local services. It also has admin backoffice.

---

# Core Principles

Hospitality OS is built around several principles.

## 1. Modular

Everything is a module.

Examples:

- Check-in
- Guest Portal
- Breakfast
- FAQ
- Recommendations
- Weather
- Bike Rental
- Luggage Storage
- Payments
- AI Assistant (long term)

Admin can select modules for different locations. 

No module should depend directly on another module.

All modules can have multiple contractors (for example in Bled there are multiple breakfast delivery sertvies).

---

## 2. Provider Based

Everything external is implemented through Providers.

Examples:

Reservation Provider

- Manual
- Bentral
- SnapGuest
- Internal Channel Manager
- Will be added in the future

Payment Provider

- SumUp
- Stripe
- PayPal

Access Provider

- Manual
- Permanent PIN
- Reservation PIN
- eKey (automatic reservation PIN)
- EasyPin (automatic reservation PIN)

Notification Provider

- Email
- WhatsApp
- SMS
- Push

The business logic never communicates directly with vendors.

Instead it communicates with provider interfaces.

---

## 3. Multi Tenant Ready

The first version is intended for a single organization.

However the architecture must already support:

Platform

↓

Organization

↓

Property

↓

Reservation

↓

Guest

No business logic may assume that only one organization exists. There must also be backoffice for admin of Hosptiality OS.

---

## 4. Configuration over Code

Almost everything should be configurable. Administartor can configure everything, host owner can configure only partials like betnral key, snapguest key... Usage of solution will be free, but we will make money on sold services.

Examples

NOT

if breakfast enabled

DO

Property Modules

Breakfast
enabled = true

---

## 5. Future Proof

The platform is designed for at least the next 10 years.

Future features should be added without major refactoring.

Examples

Today

Breakfast

Tomorrow

Airport Transfer

Boat Rental

Car Rental

Restaurant Coupons

Nothing inside the architecture should require changing the Guest Portal.

Only configuration changes.

---

# Product Goals

The platform has four main goals.

## Guest Experience

Guests should find every important information inside one portal.

No WhatsApp conversations.

No searching inside PDFs.

No manual instructions.

Everything inside one place.

---

## Owner Experience

Owners should save time.

The platform should automate repetitive work.

Examples

Reservation synchronization

Door access

Breakfast ordering

Payments

Notifications

Knowledge Base

---

## Marketplace

The platform should become a marketplace for local tourism services.

Examples

Breakfast

Bike Rental

Luggage Storage

Transfers

Restaurants

Activities

Wellness

Tickets

Every transaction can generate revenue.

---

## Automation

Everything repetitive should eventually become automated.

Examples

Reservation created

↓

Guest Portal generated

↓

PIN generated

↓

Breakfast ordered

↓

Partner notified

↓

Guest notified

↓

Checkout

↓

PIN revoked

↓

Smart devices switched off

---

# What Hospitality OS is NOT

Hospitality OS is NOT primarily a Channel Manager.

Hospitality OS is NOT primarily a PMS.

Hospitality OS is NOT a booking engine.

Those may become additional modules in the future.

The primary purpose is:

Guest Experience Platform
+
Property Automation Platform
+
Local Service Marketplace

---

# Target Customers

Primary

Small property owners

1–20 properties

---

Secondary

Professional property managers

20–500 properties

---

Future

Hotels

Glamping

Camp Sites

Holiday Villages

Luxury Villas

---

# Revenue Model

Current

Marketplace commissions

Future

Marketplace commissions

+

Channel Manager subscription

+

Premium Modules

+

Enterprise integrations

+

Partner subscriptions

---

# Technology

Backend

NodeJS

PostgreSQL

Redis

Queue Workers

Storage

---

Frontend

Vue 3

Composition API

Pinia

TypeScript (future)

---

Architecture

REST API

Provider Pattern

Module Pattern

Repository Pattern

Service Layer

Policy Based Authorization

---

# Documentation

The documentation is divided into multiple documents.

01-product-vision.md

02-business-model.md

03-domain-model.md

04-architecture.md

05-database.md

...

Each document should be treated as part of one specification.

---

# Development Principles

Never hardcode:

Countries

Languages

Providers

Services

Properties

Organizations

Everything must be configurable.

---

# Long Term Vision

Hospitality OS should become the operating system for short-term rentals.

The owner manages everything from one place.

The guest needs only one portal.

Local businesses receive bookings directly.

The platform becomes the connection between all participants.

Every module should provide MD files for documentation.